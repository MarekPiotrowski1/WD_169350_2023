import numpy as np
def function(length):
    vector = np.arange(1,length+1)
    vector = vector[::-1]
    return np.diag(vector)

print(function(3))