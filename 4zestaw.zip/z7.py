import numpy as np
def zad7(a):
    i=0
    for i in range(a):
        liczby = np.linspace(2, 2, a)
        tab = np.diag(liczby,i)
        print(i)

    print(tab)
zad7(7)