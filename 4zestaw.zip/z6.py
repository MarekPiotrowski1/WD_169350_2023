import numpy as np
def zad6():
    w1=np.array(list("malina"))
    w2=np.array(list("lizak"))
    w3=np.array(list("jagoda"))
    matrix=np.zeros((6,6),dtype=str)

    matrix[:,0]=w1
    matrix[2,:-1]=w2
    matrix[5,:]=w3[::-1]
    print(matrix)
print(zad6())