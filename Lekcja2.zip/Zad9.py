lista=[]
number=0
while True:
    number = input("Podaj liczbe")
    if(number.isdigit()==True):
        lista.append(number)
        print(lista)
    else:
        break;
