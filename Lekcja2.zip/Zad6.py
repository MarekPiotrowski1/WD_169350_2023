for i in range(51):
    if i%5==0:
        print(i)