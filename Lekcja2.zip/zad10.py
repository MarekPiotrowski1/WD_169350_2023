a=eval(input("Podaj wysokosc wieży"))
if(a>10):
    print("za duza liczba")
else:
    m=0
    for i in range(a+1):
        print(m*"A")
        m=m+1