a=eval(input("Podaj 1 liczbe"))
b=eval(input("Podaj 2 liczbe"))
c=eval(input("Podaj 3 liczbe"))
if (a >0 and a<=10) and (a>b or b>c):
    print("Warunki sa spoelnione")
else:
    print("Warunki nie sa spelnione")