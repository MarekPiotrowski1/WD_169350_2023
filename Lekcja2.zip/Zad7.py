a=input("podaj liczby oddzielone spacjami")
b=(a.split(" "))
for i in (b):
    print(int(i)**2," ")
