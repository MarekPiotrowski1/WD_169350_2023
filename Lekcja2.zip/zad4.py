a=eval(input("Podaj liczbe a ja wypisze wartosc bezwzlendna\n"))
if a<0:
    print("wartosc bezwzgledna z liczby ",a,"wynosi: ",-a)
else:
    print("wartosc bezwzgledna z liczby ",a,"wynosi: ",a)