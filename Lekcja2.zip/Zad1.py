#Zadanie1
a=input("Podaj zdanie\n")
print()
print(a.count(" "))

