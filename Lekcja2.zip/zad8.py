suma=0
a = input("Podaj liczbe wielocyfrowa a nizej wyswietli sie suma jej cyfr\n")
for i in (a):
    suma=suma+int(i)
print(suma)
