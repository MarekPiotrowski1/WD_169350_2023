def ciag(a=2,r=2,ile=3):
    suma=0
    sumas=0
    for i in range(a, ile+a):
        suma=suma+r
        sumas=sumas+suma
    return sumas
print(ciag())