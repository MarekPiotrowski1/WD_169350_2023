def rowczyprost(a1,b1,a2,b2):
    if a1==a2:
        print("Proste są równoległe")
    elif a1*a2==-1:
        print("Proste są prostopadłe")
    else:
        return 0
rowczyprost(1,3,-1,5)