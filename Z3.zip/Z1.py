def funkcja_liniowa(a,b):
    if a>0:
        print("funkcja u=",a,"x+",b,"jest rosnąca")
    elif a<0:
        print("funkcja u=",a,"x+",b,"jest malejąca")
    else:
        print("funkcja u=",a,"x+",b,"jest stała")

funkcja_liniowa(-7,5)