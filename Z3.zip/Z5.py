def wykrzyknik(a):
    b= a.split(",")
    for i in range (len(b)):
        b(i).append("!")
    print(b)
a=["zaba","kot","banan","grochowa"]
wykrzyknik(a)