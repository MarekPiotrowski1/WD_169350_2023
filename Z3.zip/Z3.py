import math
def przeciwprostokatna(a=3,b=4):
    c=(a*a)+(b*b)
    p=math.sqrt(c)
    return p
print("przeciwprostokatna ma dlugosc",przeciwprostokatna())